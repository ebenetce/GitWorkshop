function svardoc()
fp = fileparts(mfilename('fullpath'));
file = fullfile( fp , '..', 'doc', 'index.html');
open(file);
end

%[appendix]{"version":"1.0"}
%---
